import firebase_admin
from firebase_admin import credentials, firestore
from gpiozero import Button
from time import sleep

cred = credentials.Certificate("/home/admin/Documents/Firebase/serviceAccountKey.json")
firebase_admin.initialize_app(cred)

btn = Button(17)
db = firestore.client()

while True:
    button_state = btn.is_pressed

    # Update Firebase with the button state
    db.collection('inputDevices').document('button').set({'value': button_state})

    # Print the button state (you can remove this line if not needed)
    print("Button state:", button_state)

    sleep(0.1)  # Add a sleep to avoid excessive updates
