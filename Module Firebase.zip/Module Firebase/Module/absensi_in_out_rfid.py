import datetime
import socket
import firebase_admin
from firebase_admin import credentials
from firebase_admin import firestore
import threading
import RPi.GPIO as GPIO

# Inisialisasi Firebase
cred = credentials.Certificate("/home/admin/Documents/Firebase/serviceAccountKey.json")
firebase_admin.initialize_app(cred)
db = firestore.client()

# Konfigurasi RFID reader
host = '192.168.82.102'
port = 6000
address_rfid = '04 FF 0F'

# Inisialisasi GPIO
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

button_pins = [17, 27, 22]
relay_pins = [1, 7, 8]

for button_pin in button_pins:
    GPIO.setup(button_pin, GPIO.IN, pull_up_down=GPIO.PUD_UP)

for relay_pin in relay_pins:
    GPIO.setup(relay_pin, GPIO.OUT)
    GPIO.output(relay_pin, GPIO.LOW)

# Fungsi untuk menghitung CRC
def crc(cmd):
    cmd = bytes.fromhex(cmd)
    viCrcValue = 0xFFFF
    for x in range(len(cmd)):
        viCrcValue = viCrcValue ^ cmd[x]
        for y in range(8):
            if viCrcValue & 0x0001:
                viCrcValue = (viCrcValue >> 1) ^ 0x8408
            else:
                viCrcValue = viCrcValue >> 1
    crc_H = (viCrcValue >> 8) & 0xFF
    crc_L = viCrcValue & 0xFF
    cmd = cmd + bytes([crc_L])
    cmd = cmd + bytes([crc_H])
    return cmd

# Fungsi untuk mengirim perintah ke RFID reader dan menerima respons
def send_cmd(cmd):
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(5)
            s.connect((host, port))
            message = crc(cmd)
            s.sendall(message)
            data = s.recv(64)
            response_hex = data.hex().upper()
            hex_list = [response_hex[i:i + 4] for i in range(0, len(response_hex), 4)]
            hex_space = ''.join(hex_list)
            return hex_space
    except socket.error as e:
        print(f"Socket error: {e}")
        return None
    except Exception as e:
        print(f"An error occurred: {e}")
        return None

def read_and_display():
    try:
        tid_result = send_cmd(address_rfid)
        if tid_result:
            doc_ref = db.collection('Pegawai').where('RFID', '==', tid_result).stream()
            for doc in doc_ref:
                data = doc.to_dict()
                print("---------------------")
                print(f"RFID: {tid_result[12:16]}")
                mark_attendance(data['nama'], data['RFID'])

                # Mengatur kondisi untuk mengaktifkan relay sesuai dengan kode RFID yang terdeteksi
                if tid_result[12:16] == 'D111':
                    activate_relay(relay_pins[0])  # Relay 1
                elif tid_result[12:16] == 'D222':
                    activate_relay(relay_pins[0])  # Relay 1
                    activate_relay(relay_pins[1])  # Relay 2
                elif tid_result[12:16] == 'D333':
                    activate_relay(relay_pins[0])  # Relay 1
                    activate_relay(relay_pins[1])  # Relay 2
                    activate_relay(relay_pins[2])  # Relay 3

                # Atur timer untuk mematikan relay setelah 3 detik
                threading.Timer(3, deactivate_relays).start()

        else:
            print("No response received from the RFID reader.")
    except Exception as e:
        print(f"An error occurred: {e}")

# Fungsi untuk mematikan semua relay
def deactivate_relays():
    for relay_pin in relay_pins:
        deactivate_relay(relay_pin)


# Fungsi untuk menandai kehadiran
def mark_attendance(nama, rfid):
    try:
        # Check jika waktu sekarang setelah jam 16:00
        current_time = datetime.datetime.now().time()
        closing_time = datetime.time(16, 0, 0)

        if current_time > closing_time:
            # Perbarui 'jam_pulang' untuk entri yang ada
            query_update = db.collection('Absensi').where('rfid', '==', rfid).where('tanggal_masuk', '==', datetime.datetime.now().strftime("%Y-%m-%d"))
            docs = query_update.stream()
            for doc in docs:
                doc_ref = db.collection('Absensi').document(doc.id)
                doc_ref.update({'jam_pulang': datetime.datetime.now().strftime("%H:%M:%S")})
            print(f"{nama} berhasil absen pulang pada {datetime.datetime.now().strftime('%H:%M:%S - %d/%m/%Y')}.")
        else:
            # Check jika entri sudah ada untuk hari ini
            query_check = db.collection('Absensi').where('rfid', '==', rfid).where('tanggal_masuk', '==', datetime.datetime.now().strftime("%Y-%m-%d"))
            docs = query_check.stream()
            count = sum(1 for _ in docs)

            if count == 0:
                # Masukkan ke koleksi 'Absensi' jika entri belum ada
                attendance_data = {
                    'rfid': rfid,
                    'nama': nama,
                    'tanggal_masuk': datetime.datetime.now().strftime("%Y-%m-%d"),
                    'jam_masuk': datetime.datetime.now().strftime("%H:%M:%S")
                }
                db.collection('Absensi').add(attendance_data)
                print(f"{nama} berhasil absen pada {datetime.datetime.now().strftime('%H:%M:%S - %d/%m/%Y')}.")
            else:
                # Dapatkan 'jam_masuk' terawal dari entri yang ada
                query_min_jam_masuk = db.collection('Absensi').where('rfid', '==', rfid).where('tanggal_masuk', '==', datetime.datetime.now().strftime("%Y-%m-%d"))
                docs = query_min_jam_masuk.stream()
                min_jam_masuk = min(doc.to_dict()['jam_masuk'] for doc in docs)
                print(f"{nama} sudah absen pada {min_jam_masuk} - {datetime.datetime.now().strftime('%d/%m/%Y')}.")

    except Exception as e:
        print(f"Error: {e}")

# Fungsi untuk membaca terus-menerus dan menampilkan data
def continuous_reading():
    try:
        while True:
            read_and_display()
    except KeyboardInterrupt:
        print("Loop reading stopped.")

# Fungsi untuk menangani tombol yang ditekan
def button_pressed(button_index):
    print(f"Tombol {button_index + 1} ditekan.")
    activate_relay(relay_pins[button_index])
    # Menunggu 5 detik sebelum mematikan relay
    threading.Timer(5, deactivate_relay, args=(relay_pins[button_index],)).start()

# Aktifkan relay
def activate_relay(relay_pin):
    GPIO.output(relay_pin, GPIO.HIGH)

# Matikan relay
def deactivate_relay(relay_pin):
    GPIO.output(relay_pin, GPIO.LOW)

try:
    # Mulai thread untuk pembacaan RFID
    thread_reading = threading.Thread(target=continuous_reading)
    thread_reading.daemon = True
    thread_reading.start()

    # Menunggu tombol ditekan
    while True:
        for i, button_pin in enumerate(button_pins):
            if GPIO.input(button_pin) == GPIO.LOW:
                button_pressed(i)

except KeyboardInterrupt:
    print("Program dihentikan.")
finally:
    # Bersihkan GPIO
    GPIO.cleanup()
