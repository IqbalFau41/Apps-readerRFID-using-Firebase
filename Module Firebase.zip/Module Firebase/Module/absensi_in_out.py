import time
import datetime
import socket
import firebase_admin
from firebase_admin import credentials
from firebase_admin import firestore

# Inisialisasi Firebase
cred = credentials.Certificate("/home/admin/Documents/Firebase/serviceAccountKey.json")
firebase_admin.initialize_app(cred)
db = firestore.client()

# Konfigurasi RFID reader
host = '192.168.82.102'
port = 6000
address_rfid = '04 FF 0F'

# Interval pembacaan
interval_seconds = 1

def crc(cmd):
    cmd = bytes.fromhex(cmd)
    viCrcValue = 0xFFFF
    for x in range(len(cmd)):
        viCrcValue = viCrcValue ^ cmd[x]
        for y in range(8):
            if viCrcValue & 0x0001:
                viCrcValue = (viCrcValue >> 1) ^ 0x8408
            else:
                viCrcValue = viCrcValue >> 1
    crc_H = (viCrcValue >> 8) & 0xFF
    crc_L = viCrcValue & 0xFF
    cmd = cmd + bytes([crc_L])
    cmd = cmd + bytes([crc_H])
    return cmd

def send_cmd(cmd):
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(5)  
        s.connect((host, port))
        message = crc(cmd)
        s.sendall(message)
        data = s.recv(64)
        response_hex = data.hex().upper()
        hex_list = [response_hex[i:i + 4] for i in range(0, len(response_hex), 4)]
        hex_space = ''.join(hex_list)
        s.close()
        return hex_space
    except socket.error as e:
        print(f"Socket error: {e}")
    except Exception as e:
        print(f"An error occurred: {e}")

def read_and_display():
    try:
        tid_result = send_cmd(address_rfid)
        if tid_result:
            doc_ref = db.collection('Pegawai').where('RFID', '==', tid_result).stream()
            for doc in doc_ref:
                data = doc.to_dict()
                print("---------------------")
                print("Status:")
                mark_attendance(data['nama'], data['RFID'])
        else:
            print("No response received from the RFID reader.")
    except Exception as e:
        print(f"An error occurred: {e}")

def mark_attendance(nama, rfid):
    try:
        # Check if the current time is after 16:00
        current_time = datetime.datetime.now().time()
        closing_time = datetime.time(17, 0, 0)

        if current_time > closing_time:
            # Update 'jam_pulang' for existing entry
            query_update = db.collection('Absensi').where('rfid', '==', rfid).where('tanggal_masuk', '==', datetime.datetime.now().strftime("%Y-%m-%d"))
            docs = query_update.stream()
            for doc in docs:
                doc_ref = db.collection('Absensi').document(doc.id)
                doc_ref.update({'jam_pulang': datetime.datetime.now().strftime("%H:%M:%S")})
            print(f"{nama} berhasil absen pulang pada {datetime.datetime.now().strftime('%H:%M:%S - %d/%m/%Y')}.")
        else:
            # Check if entry already exists for today
            query_check = db.collection('Absensi').where('rfid', '==', rfid).where('tanggal_masuk', '==', datetime.datetime.now().strftime("%Y-%m-%d"))
            docs = query_check.stream()
            count = sum(1 for _ in docs)

            if count == 0:
                # Insert into the 'Absensi' collection if entry does not exist
                attendance_data = {
                    'rfid': rfid,
                    'nama': nama,
                    'tanggal_masuk': datetime.datetime.now().strftime("%Y-%m-%d"),
                    'jam_masuk': datetime.datetime.now().strftime("%H:%M:%S")
                }
                db.collection('Absensi').add(attendance_data)
                print(f"{nama} berhasil absen pada {datetime.datetime.now().strftime('%H:%M:%S - %d/%m/%Y')}.")
            else:
                # Get the earliest 'jam_masuk' from existing entries
                query_min_jam_masuk = db.collection('Absensi').where('rfid', '==', rfid).where('tanggal_masuk', '==', datetime.datetime.now().strftime("%Y-%m-%d"))
                docs = query_min_jam_masuk.stream()
                min_jam_masuk = min(doc.to_dict()['jam_masuk'] for doc in docs)
                print(f"{nama} sudah absen pada {min_jam_masuk} - {datetime.datetime.now().strftime('%d/%m/%Y')}.")

    except Exception as e:
        print(f"Error: {e}")

def continuous_reading(interval):
    try:
        while True:
            read_and_display()
            time.sleep(interval)  # Menunggu sebelum membaca lagi
    except KeyboardInterrupt:
        print("Loop reading stopped.")

continuous_reading(interval_seconds)
