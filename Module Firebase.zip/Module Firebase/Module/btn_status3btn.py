import RPi.GPIO as GPIO
import time
import threading
import firebase_admin
from firebase_admin import credentials, firestore

# Inisialisasi GPIO
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)
button_pins = [17, 27, 22]
relay_pins = [1, 7, 8]

for button_pin in button_pins:
    GPIO.setup(button_pin, GPIO.IN, pull_up_down=GPIO.PUD_UP)

for relay_pin in relay_pins:
    GPIO.setup(relay_pin, GPIO.OUT)
    GPIO.output(relay_pin, GPIO.LOW)

# Inisialisasi Firebase
cred = credentials.Certificate("/home/admin/Documents/Firebase/serviceAccountKey.json")
firebase_admin.initialize_app(cred)
db = firestore.client()

def activate_relay(relay_pin):
    GPIO.output(relay_pin, GPIO.HIGH)

def deactivate_relay(relay_pin):
    GPIO.output(relay_pin, GPIO.LOW)

def button_pressed(button_index):
    print(f"Tombol {button_index + 1} ditekan.")
    activate_relay(relay_pins[button_index])
    time.sleep(5)
    deactivate_relay(relay_pins[button_index])

def send_button_state(button_state):
    db.collection('inputDevices').document('buttons').update({'button1': button_state[0], 'button2': button_state[1], 'button3': button_state[2]})

try:
    while True:
        button_state = [GPIO.input(pin) == GPIO.LOW for pin in button_pins]
        for i, pin_state in enumerate(button_state):
            if pin_state:
                threading.Thread(target=button_pressed, args=(i,)).start()
        send_button_state(button_state)
        time.sleep(0.5)

except KeyboardInterrupt:
    GPIO.cleanup()
