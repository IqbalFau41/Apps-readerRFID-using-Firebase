import RPi.GPIO as GPIO
import time
import threading

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

button_pins = [17, 27, 22]
relay_pins = [1, 7, 8]

for button_pin in button_pins:
    GPIO.setup(button_pin, GPIO.IN, pull_up_down=GPIO.PUD_UP)

for relay_pin in relay_pins:
    GPIO.setup(relay_pin, GPIO.OUT)
    GPIO.output(relay_pin, GPIO.LOW)

def activate_relay(relay_pin):
    GPIO.output(relay_pin, GPIO.HIGH)

def deactivate_relay(relay_pin):
    GPIO.output(relay_pin, GPIO.LOW)

def button_pressed(button_index):
    print(f"Tombol {button_index + 1} ditekan.")
    activate_relay(relay_pins[button_index])
    time.sleep(5)
    deactivate_relay(relay_pins[button_index])

try:
    while True:
        for i, button_pin in enumerate(button_pins):
            if GPIO.input(button_pin) == GPIO.LOW:
                threading.Thread(target=button_pressed, args=(i,)).start()

except KeyboardInterrupt:
    GPIO.cleanup()
