import socket
import firebase_admin
from firebase_admin import credentials
from firebase_admin import firestore

# Inisialisasi Firebase menggunakan file kredensial
cred = credentials.Certificate("/home/admin/Documents/Firebase/serviceAccountKey.json")
firebase_admin.initialize_app(cred)

# Referensi koleksi di Firebase
db = firestore.client()
collection_ref = db.collection('rfid_data')

host = '192.168.82.102'
port = 6000
address_rfid = '04 FF 0F'
PRESENT_Value = 0xFFFF
POLYNOMIAL = 0x8408

def crc(cmd):
    cmd = bytes.fromhex(cmd)
    viCrcValue = PRESENT_Value
    for x in range(len(cmd)):
        viCrcValue = viCrcValue ^ cmd[x]
        for y in range(8):
            if viCrcValue & 0x0001:
                viCrcValue = (viCrcValue >> 1) ^ POLYNOMIAL
            else:
                viCrcValue = viCrcValue >> 1
    crc_H = (viCrcValue >> 8) & 0xFF
    crc_L = viCrcValue & 0xFF
    cmd = cmd + bytes([crc_L])
    cmd = cmd + bytes([crc_H])
    return cmd

def send_cmd(cmd):
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(5)  
        s.connect((host, port))
        message = crc(cmd)
        s.sendall(message)
        data = s.recv(64)
        response_hex = data.hex().upper()
        hex_list = [response_hex[i:i + 4] for i in range(0, len(response_hex), 4)]
        hex_space = ''.join(hex_list)
        s.close()
        return hex_space
    except socket.error as e:
        print(f"Socket error: {e}")
    except Exception as e:
        print(f"An error occurred: {e}")

def read_and_display():
    # Membaca TID
    tid_result = send_cmd(address_rfid)
    print(f"Result: {tid_result}")

    # Simpan hasil pembacaan ke Firebase
    save_to_firebase(tid_result)

def save_to_firebase(data):
    doc_ref = collection_ref.document()
    doc_ref.set({
        'timestamp': firestore.SERVER_TIMESTAMP,
        'tid_result': data
    })

# Mulai pembacaan sekali
read_and_display()
